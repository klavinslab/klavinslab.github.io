(* ::Package:: *)

(* ::Title:: *)
(*ARC analysis package*)


(* ::Subtitle:: *)
(**)


(* ::Section::Closed:: *)
(*Model Equation & Analytical Expressions*)


(* ::Text:: *)
(*The ARC model described in the paper (full circuit)*)


fc[p_]:=(model[p]=First[x3/.NDSolve[{
	x1'[t]==p[[1]](aux=1)-p[[2]]x1[t],
	x2'[t]==p[[3]]-p[[4]]x2[t]-p[[5]]x1[t]x2[t],
	x3'[t]==-p[[6]] x3[t]+p[[7]]/(1+p[[8]]x2[t]),
	x1[0]==0,
	x2[0]==p[[3]]/p[[4]],
	x3[0]==(p[[4]]p[[7]])/(p[[6]](p[[4]]+p[[3]]p[[8]]))},{x1,x2,x3},{t,1000}]])/;VectorQ[Flatten[p],NumberQ]


(* ::Text::Italic:: *)
(*The initial and final steady-state of the GFP fluorescence level; solved analytically by setting aux = 0 or aux = 1 in the ARC model and solving for steady-state.*)


initG[p_]:=(p[[4]]p[[7]])/(p[[6]](p[[4]]+p[[3]]p[[8]]))
finG[p_]:=(p[[7]](p[[2]]p[[4]]+p[[1]]p[[5]]))/(p[[6]](p[[2]]p[[4]]+p[[1]]p[[5]]+p[[2]]p[[3]]p[[8]]))


(* ::Text:: *)
(*The numerical approximation of time at which the fluorescence level reaches 0% to 100% (normalized by the initla and final GFP level).*)


findT[p_,frac_]:=Module[{f},
	f=fc[p];
	s/.FindRoot[f[s]==initG[p]+frac(finG[p]-initG[p]),{s,0,1000}]
];


(* ::Text:: *)
(*The AFB|IAA model from Havens (2012).*)


ai[p_]:=(model[p]=First[x2/.NDSolve[{
	x1'[t]==p[[1]](aux=1)-p[[2]]x1[t],
	x2'[t]==p[[3]]-p[[4]]x2[t]-p[[5]]x1[t]x2[t],
	x1[0]==0,
	x2[0]==p[[3]]/p[[4]]},{x1,x2},{t,1000}]])/;VectorQ[Flatten[p],NumberQ]



(* ::Section::Closed:: *)
(*Fit*)


(* ::Text:: *)
(*A function to fit the individual GFP time series to the model shown above. The function requires two arguments, 1) the timte series data, and 2) a reference parameter vector. The reference vector is used to define random uniform distributions from which the initial guess for the parameter vector is sampled. The constraint that all of the elements in the parameter vector is positive is imposed. NMinimize is used to minimize the value of residualGFP function, which is 2-norm value of the difference between model predicted value (funciont of the parameter vector being optimized) and the time series data. The outputs are 1) the residual value, 2) the fitted parameter vector, and 3) the overlay plot of the measured time-series and model predicted GFP levels as a function of time. *)


fit[da_,ref\[Theta]_]:=Monitor[Module[
	{d,yi,yf,l,\[Theta],guess,const,f,maxIter=50,J,fit},
	d=Sort[da,#1[[1]]<#2[[1]]&];
	yi=d[[1,2]];
	yf=Mean[d[[-3;;-1,2]]];
	l=Length[d];	
	\[Theta]=Table[ToExpression["k"<>ToString[kk]],{kk,8}];
	guess=Table[{\[Theta][[kk]],0.5ref\[Theta][[kk]], 1.5ref\[Theta][[kk]]},{kk,8}];
	const=Table[\[Theta][[kk]]>0,{kk,8}];
	const=LogicalExpand[And@@const];
	{iter,eval}={0,0};
	{J,fit}=NMinimize[{residualGFP[d,\[Theta]],const},guess,
		StepMonitor:>{iter++,Sow[\[Theta]](*,Write[stmp,{ii,mm,iter,\[Theta]}]*)},
		MaxIterations->maxIter,
		WorkingPrecision->4,EvaluationMonitor:>{eval++},
		Method->{"DifferentialEvolution","PostProcess"->False}]//Quiet;
	f=fc[\[Theta]/.fit];
	{J, \[Theta]/.fit,Show[
		ListPlot[d[[1;;l,1;;2]],PlotMarkers->Automatic,PlotStyle->Blue],
		Plot[f[s],{s,0,350},PlotRange->All],
		PlotRange->{0,8000},AxesOrigin->{0,0}]}
	],{iter,eval}];


(* ::Text:: *)
(*The residualGFP function measures the 2-norm difference between the measured time-series data of the ARC GFP response as a function of time and the model predicted GFP level. Since the number of data points in each time-series differ, the 2-norm value is normalized by the number of observation, effectively representing the average error of the model prediction at each individual observation. *)


residualGFP[data_,ref\[Theta]_]:=Module[{l,M2,f},
	l=Length[data];
	f=fc[ref\[Theta]];
	Norm[(f[data[[All,1]]]-data[[All,2]])/data[[All,2]],2]/l
]/;VectorQ[Flatten[ref\[Theta]],NumberQ];


(* ::Text:: *)
(*The residualYFP function is similar to the residualGFP function, but it computes the 2-norm difference between the measured time-series data of the ARC YFP response as a function of time and the model predicted YFP level.*)


residualYFP[data_,ref\[Theta]_]:=Module[{l,f},
	l=Length[data];
	f=ai[ref\[Theta]];
	Norm[(f[data[[All,1]]]-data[[All,2]]),2]/l
]/;VectorQ[Flatten[ref\[Theta]],NumberQ];


(* ::Section::Closed:: *)
(*PCM *)


(* ::Text:: *)
(*The following code includes all the functions required to do the analysis discussed in the Supplementary Informaiton text. It is meant to be a general package that can be used with appropriately defined ODE models of a dynamic system that are composed of two or three components. Extending the code to systems of four more more components requires minor modification of the Which function in some functions. *)


(* ::Text:: *)
(*The function outputs the elementary parameter vector of size m.*)


parameter[m_]:=Table[ToExpression["k"<>ToString[kk]],{kk,m}];


(* ::Text:: *)
(*The function outputs the expanded parameter vector of size m for a system with n components, each component with Subscript[\[Mu], i] variants. The output of the function is an m x Subscript[\[Mu], 1]x Subscript[\[Mu], 2] array with indices of the format "k"+"index of the first component"+"index of the second component"+...*)


totalParameter[M_,\[Theta]_,\[Mu]_]:=Module[{\[Theta]tot,dim},
	dim=Dimensions[M];
	Which[dim[[2]]==2,
		\[Theta]tot=Table[ToExpression[ToString[\[Theta][[kk]]]<>IntegerString[ai,10,2]<>IntegerString[bi,10,2]],{kk,Length[\[Theta]]},{ai,\[Mu][[1]]},{bi,\[Mu][[2]]}],
		dim[[2]]==3,
		\[Theta]tot=Table[ToExpression[ToString[\[Theta][[kk]]]<>IntegerString[ai,10,2]<>IntegerString[bi,10,2]<>IntegerString[ci,10,2]],{kk,Length[\[Theta]]},{ai,\[Mu][[1]]},{bi,\[Mu][[2]]},{ci,\[Mu][[2]]}]];
	\[Theta]tot
];


(* ::Text:: *)
(*The function outputs the constraints over the expanded parameter vector, specifically the equality constraint defined by the PCM. For instance, if the input PCM has 0 at position (1,1), the equlaity constraint expression for the first element in the parameter vector across the group of the system with variations in the first component is generated (e.g. k10101 == k10201 == k10301==...)*)


constraints[M_,\[Theta]_,\[Mu]_,pY_:{}]:=Module[{const,\[Theta]tot,dim},
	const={};
	dim=Dimensions[M];
	\[Theta]tot=totalParameter[M,\[Theta],\[Mu]];
	Which[dim[[2]]==2,
		{For[kk=1,kk<=Length[\[Theta]],kk++,
			If[M[[kk,1]]==0,
				const=Append[const,Table[\[Theta]tot[[kk,ii,jj]]==\[Theta]tot[[kk,ii+1,jj]],{jj,\[Mu][[2]]},{ii,\[Mu][[1]]-1}]];
			];
			If[M[[kk,2]]==0,
				const=Append[const,Table[\[Theta]tot[[kk,ii,jj]]==\[Theta]tot[[kk,ii,jj+1]],{ii,\[Mu][[1]]},{jj,\[Mu][[2]]-1}]];
			];
		];
		const=Join[const,Table[\[Theta]tot[[kk,ii,jj]]>0,{kk,Length[\[Theta]]},{ii,\[Mu][[1]]},{jj,\[Mu][[2]]}]];
		If[pY!={},
			const=Join[const,Table[\[Theta]tot[[kk,1,1]]==pY[[kk,1,1]],{kk,Length[\[Theta]]}]];
		]},
		dim[[2]]==3,
		{For[kk=1,kk<=Length[\[Theta]],kk++,
			If[M[[kk,1]]==0,
				const=Append[const,Table[\[Theta]tot[[kk,ii,jj,ll]]==\[Theta]tot[[kk,ii+1,jj,ll]],{jj,\[Mu][[2]]},{ll,\[Mu][[3]]},{ii,\[Mu][[1]]-1}]];
			];
			If[M[[kk,2]]==0,
				const=Append[const,Table[\[Theta]tot[[kk,ii,jj,ll]]==\[Theta]tot[[kk,ii,jj+1,ll]],{ii,\[Mu][[1]]},{ll,\[Mu][[3]]},{jj,\[Mu][[2]]-1}]];
			];
			If[M[[kk,3]]==0,
				const=Append[const,Table[\[Theta]tot[[kk,ii,jj,ll]]==\[Theta]tot[[kk,ii,jj,ll+1]],{ii,\[Mu][[1]]},{jj,\[Mu][[2]]},{ll,\[Mu][[3]]-1}]];
			];
		];
		const=Join[const,Table[\[Theta]tot[[kk,ii,jj,ll]]>0,{kk,Length[\[Theta]]},{ii,\[Mu][[1]]},{jj,\[Mu][[2]]},{ll,\[Mu][[3]]}]];
		If[pY!={},
			const=Join[const,Table[\[Theta]tot[[kk,1,1,1]]==pY[[kk,1,1,1]],{kk,Length[\[Theta]]}]]]
		}];
	const=LogicalExpand[And@@Flatten[const]]
]


(* ::Text:: *)
(*The function outputs the uniform distribution from which the NMinimize function samples the initial guesses from. The reference parameter vector is used to define the interval between 50% and the 150% of the reference values. *)


initGuess[M_,\[Theta]_,\[Mu]_,pY_]:=Module[{dim,\[Theta]tot,guess,p0},
	dim=Dimensions[M];
	\[Theta]tot=totalParameter[M,\[Theta],\[Mu]];
	p0=pY/.{0->10^-6};
	Which[dim[[2]]==2,
		guess=Table[{\[Theta]tot[[kk,ii,jj]],0.5p0[[kk,ii,jj]],1.5p0[[kk,ii,jj]]},{kk,Length[\[Theta]]},{ii,\[Mu][[1]]},{jj,\[Mu][[2]]}],
		dim[[2]]==3,
		guess=Table[{\[Theta]tot[[kk,ii,jj,ll]],0.5p0[[kk,ii,jj,ll]],1.5p0[[kk,ii,jj,ll]]},{kk,Length[\[Theta]]},{ii,\[Mu][[1]]},{jj,\[Mu][[2]]},{ll,\[Mu][[3]]}]];
	guess=Flatten[guess,dim[[2]]]
];


(* ::Text:: *)
(*The function outputs the residual value corresponding to an expanded parameter vector, a set of time-series data. Internally it defines a function, g, that is an array of user-defined f (the original model of the system) functions. The g is used to populate the model predicted GFP intensity and computes the metric between it and the corresponding time-series data (by default, the function uses 2-norm, but an optional argument can be specified to use 1-norm (option 2) or numerical integration (option 3) to compute the area between the model predicted GFP curve and the interpolated curve of the time-series. *)


res[p_,segD_,method_:1]:=Module[{g,\[Mu],ans},
	\[Mu]=Dimensions[segD];
	Which[((Length[\[Mu]]-2)==2 || Length[\[Mu]]==2),
		{g=Table[f[p,c1,c2],{c1,\[Mu][[1]]},{c2,\[Mu][[2]]}];
		ans=Table[
			Which[method==1, (*2-norm*)
				Norm[(g[[c1,c2]][segD[[c1,c2,All,1]]]-segD[[c1,c2,All,2]]),2],
				method==2, (*abs*)
				Abs[(g[[c1,c2]][segD[[c1,c2,All,1]]]-segD[[c1,c2,All,2]])],
				method==3, (*NIntegrate*)
				NIntegrate[Abs[f[p,c1,c2][s]-Interpolation[data[[c1,c2,All,1;;2]]][s]],{s,0,Max[data[[c1,c2,All,1]]]}]
			],
			{c1,\[Mu][[1]]},{c2,\[Mu][[2]]}]//Flatten//Total},
		(Length[\[Mu]]-2)==3,
		{g=Table[f[p,c1,c2,c3],{c1,\[Mu][[1]]},{c2,\[Mu][[2]]},{c3,\[Mu][[3]]}];
		ans=Table[
			Which[method==1, (*2-norm*)
				Norm[(g[[c1,c2,c3]][segD[[c1,c2,c3,All,1]]]-segD[[c1,c2,c3,All,2]]),2],
				method==2, (*abs*)
				Abs[(g[[c1,c2,c3]][segD[[c1,c2,c3,All,1]]]-segD[[c1,c2,c3,All,2]])],
				method==3, (*NIntegrate*)
				NIntegrate[Abs[f[p,c1,c2,c3][s]-Interpolation[data[[c1,c2,c3,All,1;;2]]][s]],{s,0,Max[data[[c1,c2,c3,All,1]]]}]
			],
			{c1,\[Mu][[1]]},{c2,\[Mu][[2]]},{c3,\[Mu][[3]]}]//Flatten//Total}
	];
	ans
]/;VectorQ[Flatten[p],NumberQ];


(* ::Text:: *)
(*The function outputs 1) the residual value and 2) the fitted parameter vector. The arguments are 1) PCM that defines the constraints across the expanded parameter vector, 2) an internal selection of the data (this can be either the entire data set or a smaller subset to reduce the computational cost), 3) a reference parameter vector, and 4) an optional argument for maxIteration (used by NMinimize). *)


fitInit[M_,is_,pY_,mI_:150]:=Monitor[Module[{\[Theta],\[Theta]tot,max,segD,\[Mu],const,f1,guess,J,fit,dim},
(*Set the dimensions of the iterator*)
\[Mu]=Map[Length,is];
dim=Dimensions[M];

(*Select the subset of the data*)
Which[dim[[2]]==2,
	segD=data[[is[[1]],is[[2]]]],
	dim[[2]]==3,
	segD=data[[is[[1]],is[[2]],is[[3]]]]
];

(*define the template model parameter*)
\[Theta]=Table[ToExpression["k"<>ToString[kk]],{kk,dim[[1]]}];

(*generate the expanded parameter vector for the data set*)
\[Theta]tot=totalParameter[M,\[Theta],\[Mu]];

(*generate the constraints based on M*)
const=constraints[M,\[Theta],\[Mu]];

(*define the initial guess for the optimization algorithm*)
guess=initGuess[M,\[Theta],\[Mu],pY];

(*optimize*)
{iter,eval}={0,0};
{J,fit}=NMinimize[{res[\[Theta]tot,segD],const},guess,
		StepMonitor:>{iter++},
		MaxIterations->mI,WorkingPrecision->4,EvaluationMonitor:>{eval++},
		Method->{"DifferentialEvolution","PostProcess"->False}]//Quiet;

(*Plot the results*)
(*f1=Table[f[\[Theta]tot/.fit,c1,c2,c3],{c1,\[Mu]1},{c2,\[Mu]2},{c3,\[Mu]2}];
max=Ceiling[Max[Flatten[segD\[LeftDoubleBracket]All,All,All,All,2\[RightDoubleBracket]]],0.1];
{J,fit,Table[
Show[
Plot[f1\[LeftDoubleBracket]c1,c2,c3\[RightDoubleBracket][s],{s,0,10},PlotRange\[Rule]All],
ListPlot[segD\[LeftDoubleBracket]c1,c2,c3,All,1;;2\[RightDoubleBracket],PlotMarkers\[Rule]Automatic],PlotRange\[Rule]{0,max}
],{c1,\[Mu]1},{c2,\[Mu]2},{c3,\[Mu]2}]}*)
{J,fit}

]
,{iter,eval}]


(* ::Text:: *)
(*The function executes greedy search algorithm. It has a threshold value that is used to determine whether the reduction in model residual from previous iteration to current iteration is sufficiently great that the benefits of adding another non-zero element to the PCM has not saturated. It outputs the correspoding PCM, model residual, and fitted parameter vector of all the PCM candidates that it explores. It also saves the intermediate results in the current folder with the fileName. *)


TolSearch[\[Theta]_,m_,n_,sel_,p0_,fileName_,tol_:0.01,maxIter_:100]:=Monitor[Module[{\[Theta]tot,oldFun,newFun,best,ones,sr,sort},
	\[Theta]tot=totalParameter[SparseArray[{},{m,n}],\[Theta],Map[Length,sel]];

	itt=1;
	sr=Table[Null,{m*n}];
	sr[[itt]]={};

	result=Table[{},{m*n}];
	result[[itt]]=Append[result[[itt]],Join[{sr[[itt]]},fitInit[SparseArray[sr[[itt]],{m,n}],sel,p0,maxIter]]];
	DumpSave[fileName,result];

	best=Table[{},{ii,m*n}];
	best[[itt]]=\[Theta]tot/.result[[itt,1,3]];

	ones={};
	oldFun=\[Infinity];
	newFun=Min[result[[itt,All,2]]];

	While[(oldFun-newFun)/(1+newFun)>tol,
		(*For[iter=2,iter\[LessEqual]6,iter++,*)
		itt=itt+1;

		sr[[itt]]=Flatten[Delete[Table[Join[{{ii,jj}->1},Thread[ones->1]],{ii,m},{jj,n}],ones],1];
		l=Length[sr[[itt]]];
		(*For now, we pull the optimization result from previous result*)
		For[eva=1,eva<=l,eva++,
			result[[itt]]=Append[result[[itt]],
				Join[{sr[[itt,eva]]},
				fitInit[SparseArray[sr[[itt,eva]],{m,n}],sel,best[[itt-1]],maxIter]
			]];
			DumpSave[fileName,result];
		];

	sort=Ordering[result[[itt,All,2]]];
	ones=result[[itt,sort[[1]],1,All,1]];
	best[[itt]]=\[Theta]tot/.result[[itt,sort[[1]],3]];
	Print[ones];

	oldFun=newFun;
	newFun=Min[result[[itt,All,2]]];
	];
	result
],{itt,eva}];


(* ::Section::Closed:: *)
(*Visualization*)


(* ::Text:: *)
(*The function outputs a Graphics object that plots the model predicted GFP level (using the fit arguement) as function of time overlayed with the measured time-series for the subset of datasets selected by the is argument. *)


plotFit[fit_,is_,M_]:=Module[{\[Mu],dim,f1,\[Theta],\[Theta]tot,segD,max,maxT,fullDim},
	(*Set the dimensions of the iterator*)
	\[Mu]=Map[Length,is];
	dim=Dimensions[M];
	fullDim=Dimensions[data];

	(*Select the subset of the data*)
	Which[dim[[2]]==2,
		segD=data[[is[[1]],is[[2]]]],
		dim[[2]]==3,
		segD=data[[is[[1]],is[[2]],is[[3]]]]];

	(*define the template model parameter*)
	\[Theta]=Table[ToExpression["k"<>ToString[kk]],{kk,dim[[1]]}];

	(*generate the parameter vector for the entire data set*)
	\[Theta]tot=totalParameter[M,\[Theta],\[Mu]];

	Which[dim[[2]]==2,
		{max=Max[Flatten[segD[[All,All,All,2]]]]*1.2,
		maxT=Max[Flatten[segD[[All,All,All,1]]]*1.2]},
		dim[[2]]==3,
		{max=Max[Flatten[segD[[All,All,All,All,2]]]]*1.2,
		maxT=Max[Flatten[segD[[All,All,All,All,1]]]]*1.2}
	];


	Which[dim[[2]]==2,
		{(*max=Max[Flatten[segD\[LeftDoubleBracket]All,All,All,2\[RightDoubleBracket]]],
		max=Ceiling[max,10^(Round[Log10[max*1.5]])],*)
		f1=Table[f[\[Theta]tot/.fit,c1,c2],{c1,\[Mu][[1]]},{c2,\[Mu][[2]]}]},
		dim[[2]]==3,
		{(*max=Max[Flatten[segD\[LeftDoubleBracket]All,All,All,All,2\[RightDoubleBracket]]],
		max=Ceiling[max,10^(Round[Log10[max*1.5]])],*)
		f1=Table[f[\[Theta]tot/.fit,c1,c2,c3],{c1,\[Mu][[1]]},{c2,\[Mu][[2]]},{c3,\[Mu][[3]]}]}
	];

	Which[dim[[2]]==2,
		Table[
			Show[
				Plot[f1[[c1,c2]][s],{s,0,maxT},PlotRange->All],
				ListPlot[segD[[c1,c2,All,1;;2]],PlotMarkers->Automatic],
				AxesOrigin->{0,0},
				PlotRange->{0,max},PlotLabel->"("<>ToString[Range[fullDim[[1]]][[is[[1]]]][[c1]]]<>", "<>ToString[Range[fullDim[[2]]][[is[[2]]]][[c2]]]<>")"
			],{c1,\[Mu][[1]]},{c2,\[Mu][[2]]}],
		dim[[2]]==3,
		Table[
			Show[
				Plot[f1[[c1,c2,c3]][s],{s,0,maxT},PlotRange->All],
				ListPlot[segD[[c1,c2,c3,All,1;;2]],PlotMarkers->Automatic],
				AxesOrigin->{0,0},
				PlotRange->{0,max},PlotLabel->"("<>ToString[Range[fullDim[[1]]][[is[[1]]]][[c1]]]<>", "<>ToString[Range[fullDim[[2]]][[is[[2]]]][[c2]]]<>", "<>ToString[Range[fullDim[[3]]][[is[[3]]]][[c3]]]<>")"
			],{c1,\[Mu][[1]]},{c2,\[Mu][[2]]},{c3,\[Mu][[3]]}]
	]

]


(* ::Text:: *)
(*The function outputs a Graphics object of one iteration of the result object (obtained from the TolSearch function). It shows the parent PCM and all its PCM children, along with the corresponding residual values. The varying intensities of the red dots are meant to indicate the relative ranking among the residual values of the children, with the most intensely red dot corresponding to the child with the lowest residual value and the white dot corresponding to the child with the highest residual value.*)


plotTreeGraph[result_,iter_,{m_,n_},imagePadding_:65]:=Module[{sort,l,parent},

sort=Ordering[result[[iter,All,2]]];
parent=Ordering[result[[iter-1,All,2]],1]//First;
l=Length[sort];
Table[sort[[ii]]+1\[DirectedEdge]Blend[{Red,White},(ii-1)/(l-1)],{ii,l}];
TreeGraph[Flatten[
{
{Labeled[1,Placed[{result[[iter-1,parent,2]],MatrixForm[SparseArray[result[[iter-1,parent,1]],{m,n}]]},{Before,Above}]]},
Table[Labeled[ii,Placed[{result[[iter,ii-1,2]],MatrixForm[SparseArray[result[[iter,ii-1,1]],{m,n}]]},{Before,Below}]],{ii,2,l+1}]
}],
Table[1\[DirectedEdge]ii,{ii,2,l+1}],
VertexStyle->Table[sort[[ii]]+1-> Blend[{Red,White},(ii-1)/(l-1)],{ii,l}],
VertexSize->Medium,
ImageSize->{550,350},ImagePadding->imagePadding]
]


(* ::Text:: *)
(*The function outputs a Graphics object that visualizes the path taken by the TolSearch function, showing the PCM with the lowest residual value at each iteration (x-axis) and its corresponding residual value (y-axis). *)


plotProgress[result_,{m_,n_},imagePadding_:50]:=Module[{num1s,data,max},
num1s=0;
data={{num1s,result[[num1s+1,1,2]],result[[num1s+1,1,1]]}};
l=Length[result]-1;
For[num1s=1,num1s<=l,num1s++,
data=Append[data,{num1s,Min[result[[num1s+1,All,2]]],
Sort[result[[num1s+1,All,1;;2]],#1[[2]]<= #2[[2]]&][[1,1]]}]
];
max=Ceiling[data[[1,2]],2];
Show[
	ListPlot[data[[All,1;;2]],PlotRange->{{-1,l+1},{0,max}},Ticks-> {Range[-1,l+1],Automatic},PlotMarkers->Automatic,Joined->True,AxesOrigin->{-1,0}],
	Table[
	Graphics[Text[MatrixForm[SparseArray[data[[iter,3]],{m,n}]],{1.1,1.1}*data[[iter,1;;2]]]],{iter,l}]
	]
];


(* ::Text:: *)
(*The function sorts each slice (one iteration) of the result object from the TolSearch function in the order of increasing residual values.*)


sortResult[result_,itt_]:=Sort[result[[itt]],#1[[2]]<=#2[[2]]&];


(* ::Text:: *)
(*The function outputs a Graphics object that combines the aspects of the plotTree and the plotProgress functions. For each iteration, the parent PCM and its children PCM  are plotted with the corresponding residual values.*)


plotTreeProgress[result_,itt_,color_:{Blue,Orange}]:=Module[{maxJ,g},
maxJ=Max[Flatten[result[[All,All,2]]]];
maxJ = 10^(Log10[maxJ]*1.01);
g=Map[{{itt-1,#[[1]]},{itt,#[[2]]}}&,Thread[{sortResult[result,itt][[1,2]],result[[itt+1,All,2]]}]];
ListPlot[g,Joined->True,PlotMarkers->{Graphics[{color[[1]],Disk[]}],0.04},PlotRange->{0,maxJ},PlotStyle->color[[2]]]
];


(* ::Section:: *)
(*Helper Functions*)


result2csv[resultObject_]:=Module[{flat,\[Theta]tot, header,ss,pp},
	flat={};
	\[Theta]tot=Table[(ToExpression["k"<>ToString[kk]<>IntegerString[ii,10,2]<>IntegerString[jj,10,2]]),{ii,4},{jj,2},{kk,8}];

	header=Join[
			Flatten[Table[ToString[{ii,jj}],{ii,8},{jj,2}]],
			{"J"},
			Flatten[\[Theta]tot]
			];
	ss=1;

	While[resultObject[[ss]]!={} || ss<=Length[resultObject],
		For[pp=1,pp<=Length[resultObject[[ss]]],pp++,
			flat=Append[flat,
				Join[
					Flatten[Normal[SparseArray[resultObject[[ss,pp,1]],{8,2}]]],
					{resultObject[[ss,pp,2]]},
					Flatten[\[Theta]tot]/.resultObject[[ss,pp,3]]
				]
			];
		];
		ss=ss+1;
	];
	flat=Join[{header},
			flat
		];
	flat

]//Quiet;


csv2resultObj[flat_]:=Module[{header,srMaster, sr,ss,J,\[Theta]tot,\[Theta]tothat,result},
	result={};
	header=flat[[1]];
	srMaster=header[[1;;16]];
	\[Theta]tot=Table[(ToExpression["k"<>ToString[kk]<>IntegerString[ii,10,2]<>IntegerString[jj,10,2]]),{ii,4},{jj,2},{kk,8}];

	For[ss=2,ss<=Length[flat],ss++,
		sr=Thread[srMaster->flat[[ss,1;;16]]];
		sr=Select[sr,#[[2]]==1&];
		J=flat[[ss,17]];
		\[Theta]tothat=Thread[Flatten[\[Theta]tot]->flat[[ss,18;;-1]]];
		result=Append[result,{sr,J,\[Theta]tothat}];
	];
	result=GatherBy[result,Length[#[[1]]]&];
	result
]
